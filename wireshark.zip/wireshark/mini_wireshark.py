# Required installations:
# pip install scapy pyqt5

from scapy.all import sniff, Ether, IP, TCP, UDP, DNS, Raw
from PyQt5 import QtWidgets, QtCore
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QSplitter, QTextEdit, QTableWidget, QApplication, QVBoxLayout, QWidget
import sys

class PacketSniffer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Mini Wireshark - Python Edition")
        self.setGeometry(100, 100, 1000, 600)

        # Layouts
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        # Packet Table
        self.packet_table = QTableWidget()
        self.packet_table.setColumnCount(5)
        self.packet_table.setHorizontalHeaderLabels(["Time", "Source", "Destination", "Protocol", "Info"])
        self.packet_table.verticalHeader().setVisible(False)
        self.packet_table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.packet_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.packet_table.cellClicked.connect(self.display_packet_details)

        # Packet Detail Viewer
        self.packet_details = QTextEdit()
        self.packet_details.setReadOnly(True)

        # Splitter
        splitter = QSplitter(QtCore.Qt.Vertical)
        splitter.addWidget(self.packet_table)
        splitter.addWidget(self.packet_details)

        layout.addWidget(splitter)
        self.setCentralWidget(main_widget)

        self.packets = []  # Store packets

        # Start sniffing
        self.start_sniffing()

    def start_sniffing(self):
        self.sniffer_thread = QtCore.QThread()
        self.sniffer_worker = SnifferWorker()
        self.sniffer_worker.moveToThread(self.sniffer_thread)
        self.sniffer_thread.started.connect(self.sniffer_worker.run)
        self.sniffer_worker.packet_received.connect(self.add_packet)
        self.sniffer_thread.start()

    def add_packet(self, pkt_summary, pkt):
        row_position = self.packet_table.rowCount()
        self.packet_table.insertRow(row_position)
        for i, data in enumerate(pkt_summary):
            self.packet_table.setItem(row_position, i, QTableWidgetItem(str(data)))
        self.packets.append(pkt)

    def display_packet_details(self, row, column):
        pkt = self.packets[row]
        self.packet_details.setText(pkt.show(dump=True))


class SnifferWorker(QtCore.QObject):
    packet_received = QtCore.pyqtSignal(list, object)

    def run(self):
        sniff(prn=self.process_packet, store=False)

    def process_packet(self, packet):
        try:
            summary = [
                packet.time,
                packet[IP].src if IP in packet else "-",
                packet[IP].dst if IP in packet else "-",
                packet.lastlayer().name,
                packet.summary()
            ]
            self.packet_received.emit(summary, packet)
        except Exception as e:
            pass


if __name__ == '__main__':
    app = QApplication(sys.argv)
    sniffer_gui = PacketSniffer()
    sniffer_gui.show()
    sys.exit(app.exec_())

